"""Download Bloomberg metadata fields for Russell 3000 tickers."""
import argparse
import time
import pandas as pd
from xbbg import blp
from config import RAW_DIR, METADATA_FIELDS

TICKER_FILE = RAW_DIR / "russell3000_tickers.csv"
OUT_FILE = RAW_DIR / "russell3000_metadata.csv"
FAILED_FILE = RAW_DIR / "failed_metadata_downloads.csv"

def normalize_bdp(raw, ticker):
    df = raw.to_pandas() if hasattr(raw, "to_pandas") else raw
    df = pd.DataFrame(df)
    row = {"ticker": ticker}
    if df.empty:
        return row
    if {"field", "value"}.issubset(df.columns):
        for _, r in df.iterrows():
            row[str(r["field"])] = r["value"]
    else:
        row.update(df.iloc[0].to_dict())
    return row

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--sleep", type=float, default=0.15)
    args = parser.parse_args()
    tickers = pd.read_csv(TICKER_FILE)["ticker"].dropna().astype(str).tolist()
    if args.limit:
        tickers = tickers[:args.limit]
    rows, failed = [], []
    for i, ticker in enumerate(tickers, start=1):
        print(f"[{i}/{len(tickers)}] {ticker}")
        try:
            raw = blp.bdp(ticker, METADATA_FIELDS)
            rows.append(normalize_bdp(raw, ticker))
            if i % 50 == 0:
                pd.DataFrame(rows).to_csv(OUT_FILE, index=False)
            time.sleep(args.sleep)
        except Exception as e:
            failed.append({"ticker": ticker, "reason": str(e)})
            pd.DataFrame(failed).to_csv(FAILED_FILE, index=False)
            time.sleep(0.5)
    pd.DataFrame(rows).to_csv(OUT_FILE, index=False)
    pd.DataFrame(failed).to_csv(FAILED_FILE, index=False)
    print("Saved", OUT_FILE)

if __name__ == "__main__":
    main()
