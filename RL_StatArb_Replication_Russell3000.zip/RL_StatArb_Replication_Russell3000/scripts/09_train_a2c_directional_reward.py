"""Train A2C with directional reward shaping."""
from __future__ import annotations
import argparse
import pandas as pd
from stable_baselines3 import A2C
from stable_baselines3.common.vec_env import DummyVecEnv
from config import PROCESSED_DIR, RESULTS_DIR, MODEL_DIR, TRANSACTION_COST
from rl_helpers import FEATURES, find_years, clean_dataset, limit_pairs, scale_fit, scale_df, DiscretePairEnv, evaluate_discrete, compute_metrics

REWARD_CONFIG = {"holding_penalty": 0.00005, "extra_turnover_penalty": 0.00050, "weak_zone_penalty": 0.00030, "wrong_direction_penalty": 0.00100, "entry_z": 1.50}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--test-year", type=int, default=0)
    parser.add_argument("--max-pairs", type=int, default=100)
    parser.add_argument("--timesteps", type=int, default=100000)
    parser.add_argument("--reward-scale", type=float, default=100.0)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    years = [args.test_year] if args.test_year else find_years()
    rows, daily_all = [], []
    for year in years:
        train_df = pd.read_parquet(PROCESSED_DIR / "rl_pair_dataset" / f"rl_pairs_train_{year}.parquet")
        test_df = pd.read_parquet(PROCESSED_DIR / "rl_pair_dataset" / f"rl_pairs_test_{year}.parquet")
        features = [c for c in FEATURES if c in train_df.columns and c in test_df.columns]
        train_df = limit_pairs(clean_dataset(train_df, features), args.max_pairs)
        test_df = clean_dataset(test_df, features)
        test_df = test_df[test_df["pair_id"].isin(train_df["pair_id"].unique())].copy()
        scaler = scale_fit(train_df, features, MODEL_DIR / f"scaler_A2C_directional_{year}.joblib")
        train_scaled = scale_df(train_df, scaler, features)
        env = DummyVecEnv([lambda: DiscretePairEnv(train_scaled, features, transaction_cost=TRANSACTION_COST, reward_scale=args.reward_scale, reward_config=REWARD_CONFIG, seed=args.seed)])
        model = A2C("MlpPolicy", env, learning_rate=7e-4, n_steps=64, gamma=0.99, gae_lambda=0.95, ent_coef=0.001, verbose=0, seed=args.seed)
        model.learn(total_timesteps=args.timesteps)
        model.save(MODEL_DIR / f"A2C_directional_strong_{year}")
        log, daily = evaluate_discrete(model, test_df, scaler, features, "A2C", year)
        metrics = compute_metrics(daily, log)
        log.to_csv(RESULTS_DIR / f"trade_log_A2C_directional_strong_{year}.csv", index=False)
        daily.to_csv(RESULTS_DIR / f"daily_returns_A2C_directional_strong_{year}.csv", index=False)
        rows.append({"test_year": year, "model": "A2C", "reward_variant": "directional_strong", **REWARD_CONFIG, **metrics})
        daily_all.append(daily)
        pd.DataFrame(rows).to_csv(RESULTS_DIR / "directional_reward_results.csv", index=False)
        pd.concat(daily_all, ignore_index=True).to_csv(RESULTS_DIR / "directional_reward_daily_returns.csv", index=False)
    print("Saved directional A2C results.")

if __name__ == "__main__":
    main()
