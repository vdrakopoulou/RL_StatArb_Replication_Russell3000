"""Build Bloomberg tickers from an exported Russell 3000 membership Excel file."""
import argparse
import re
from pathlib import Path
import pandas as pd
from config import RAW_DIR

BAD_WORDS = {"TICKER", "NAME", "WEIGHT", "SHARES", "PRICE", "MEMBERS", "INDEX", "RUSSELL", "CURRENCY", "NAN"}

def extract_tickers(excel_file: Path) -> pd.DataFrame:
    raw = pd.read_excel(excel_file, header=None)
    tickers = set()
    for _, row in raw.iterrows():
        vals = ["" if pd.isna(v) else str(v).strip() for v in row.tolist()]
        for v in vals:
            m = re.fullmatch(r"([A-Z0-9./-]{1,12})\s+(U[A-Z]|US)\s+Equity", v, re.IGNORECASE)
            if m:
                tickers.add(f"{m.group(1).upper()} {m.group(2).upper()} Equity")
        for j in range(len(vals) - 1):
            symbol = vals[j].upper().replace(" ", "")
            exch = vals[j + 1].upper().replace(" ", "")
            if symbol in BAD_WORDS:
                continue
            if re.fullmatch(r"[A-Z0-9./-]{1,12}", symbol) and re.fullmatch(r"U[A-Z]|US", exch):
                tickers.add(f"{symbol} {exch} Equity")
    return pd.DataFrame({"ticker": sorted(tickers)})

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--members-file", required=True, help="Bloomberg membership Excel export")
    parser.add_argument("--output", default=str(RAW_DIR / "russell3000_tickers.csv"))
    args = parser.parse_args()
    out = extract_tickers(Path(args.members_file))
    Path(args.output).parent.mkdir(parents=True, exist_ok=True)
    out.to_csv(args.output, index=False)
    print(f"Saved {len(out)} tickers to {args.output}")
    print(out.head(20).to_string(index=False))

if __name__ == "__main__":
    main()
