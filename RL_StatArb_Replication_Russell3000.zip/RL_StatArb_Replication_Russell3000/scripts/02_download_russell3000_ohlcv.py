"""Download daily OHLCV + market cap for Russell 3000 tickers from Bloomberg."""
import argparse
import os
import time
from pathlib import Path
import pandas as pd
from xbbg import blp
from config import RAW_DIR, START_DATE, END_DATE, STOCK_FIELDS

TICKER_FILE = RAW_DIR / "russell3000_tickers.csv"
OUT_DIR = RAW_DIR / "russell3000_ohlcv"
FAILED_FILE = RAW_DIR / "failed_ohlcv_downloads.csv"
PROGRESS_FILE = RAW_DIR / "ohlcv_download_progress.csv"
OUT_DIR.mkdir(parents=True, exist_ok=True)

def safe_filename(ticker: str) -> str:
    return ticker.replace(" ", "_").replace("/", "_").replace("\\", "_").replace(":", "_").replace(".", "_")

def normalize_bdh(raw_df, ticker: str) -> pd.DataFrame:
    df = raw_df.to_pandas() if hasattr(raw_df, "to_pandas") else raw_df
    df = pd.DataFrame(df)
    if df.empty:
        return df
    if {"date", "field", "value"}.issubset(df.columns):
        out = df.pivot_table(index="date", columns="field", values="value", aggfunc="last").reset_index()
        out.columns.name = None
        out["ticker"] = ticker
        return out
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = [c[-1] if isinstance(c, tuple) else c for c in df.columns]
    out = df.reset_index()
    if "index" in out.columns and "date" not in out.columns:
        out = out.rename(columns={"index": "date"})
    out["ticker"] = ticker
    return out

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--limit", type=int, default=0)
    parser.add_argument("--sleep", type=float, default=0.35)
    args = parser.parse_args()
    tickers = pd.read_csv(TICKER_FILE)["ticker"].dropna().astype(str).tolist()
    if args.limit > 0:
        tickers = tickers[:args.limit]
    failed, progress = [], []
    print(f"Downloading {len(tickers)} tickers to {OUT_DIR}")
    for i, ticker in enumerate(tickers, start=1):
        out_file = OUT_DIR / f"{safe_filename(ticker)}.parquet"
        if out_file.exists():
            print(f"[{i}/{len(tickers)}] skip {ticker}")
            continue
        print(f"[{i}/{len(tickers)}] {ticker}")
        try:
            raw = blp.bdh(ticker, STOCK_FIELDS, start_date=START_DATE, end_date=END_DATE)
            df = normalize_bdh(raw, ticker)
            if df.empty:
                failed.append({"ticker": ticker, "reason": "empty"})
                continue
            df.to_parquet(out_file, index=False)
            progress.append({"ticker": ticker, "rows": len(df), "file": str(out_file)})
            pd.DataFrame(progress).to_csv(PROGRESS_FILE, index=False)
            pd.DataFrame(failed).to_csv(FAILED_FILE, index=False)
            time.sleep(args.sleep)
        except Exception as e:
            print("FAILED", ticker, e)
            failed.append({"ticker": ticker, "reason": str(e)})
            pd.DataFrame(failed).to_csv(FAILED_FILE, index=False)
            time.sleep(1)
    pd.DataFrame(progress).to_csv(PROGRESS_FILE, index=False)
    pd.DataFrame(failed).to_csv(FAILED_FILE, index=False)
    print("Done")

if __name__ == "__main__":
    main()
