"""Check required Python packages and folder structure."""
import importlib
from config import RAW_DIR, PROCESSED_DIR, RESULTS_DIR, MODEL_DIR, TABLE_DIR, FIGURE_DIR

REQUIRED = [
    "pandas", "numpy", "pyarrow", "openpyxl", "statsmodels", "sklearn", "gymnasium",
    "stable_baselines3", "torch", "joblib", "matplotlib", "scipy"
]
OPTIONAL = ["xbbg", "blpapi"]

print("Checking required packages:")
for pkg in REQUIRED:
    try:
        importlib.import_module(pkg)
        print("OK", pkg)
    except Exception as e:
        print("MISSING", pkg, e)

print("\nChecking Bloomberg packages:")
for pkg in OPTIONAL:
    try:
        importlib.import_module(pkg)
        print("OK", pkg)
    except Exception as e:
        print("MISSING/OPTIONAL", pkg, e)

for p in [RAW_DIR, PROCESSED_DIR, RESULTS_DIR, MODEL_DIR, TABLE_DIR, FIGURE_DIR]:
    p.mkdir(parents=True, exist_ok=True)
    print("Folder ready:", p)
