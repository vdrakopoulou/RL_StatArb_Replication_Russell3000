"""Shared helpers for RL training and evaluation."""
from __future__ import annotations
import os
import re
import glob
import numpy as np
import pandas as pd
import gymnasium as gym
from gymnasium import spaces
from sklearn.preprocessing import StandardScaler
from joblib import dump
from config import PROCESSED_DIR, RESULTS_DIR, MODEL_DIR, TRANSACTION_COST

FEATURES = pd.read_csv(PROCESSED_DIR / "rl_pair_dataset" / "feature_columns.csv")["feature"].dropna().astype(str).tolist() if (PROCESSED_DIR / "rl_pair_dataset" / "feature_columns.csv").exists() else []


def find_years():
    files = glob.glob(str(PROCESSED_DIR / "rl_pair_dataset" / "rl_pairs_train_*.parquet"))
    years = sorted({int(re.search(r"(\d{4})", os.path.basename(f)).group(1)) for f in files})
    return years


def clean_dataset(df, features):
    df = pd.DataFrame(df).copy()
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    for c in features + ["pair_return_long", "pair_return_short"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.replace([np.inf, -np.inf], np.nan).dropna(subset=features + ["pair_return_long", "pair_return_short", "date", "pair_id"])
    return df.sort_values(["pair_id", "date"]).reset_index(drop=True)


def limit_pairs(df, max_pairs):
    if max_pairs <= 0:
        return df
    scores = df.groupby("pair_id")["score"].first().reset_index() if "score" in df.columns else df[["pair_id"]].drop_duplicates()
    scores = scores.sort_values("score", ascending=False) if "score" in scores.columns else scores.sort_values("pair_id")
    keep = scores.head(max_pairs)["pair_id"].tolist()
    return df[df["pair_id"].isin(keep)].copy()


def scale_fit(train_df, features, out_file):
    scaler = StandardScaler()
    scaler.fit(train_df[features].values)
    dump(scaler, out_file)
    return scaler


def scale_df(df, scaler, features):
    out = df.copy()
    x = scaler.transform(out[features].values)
    out[features] = np.clip(x, -10, 10).astype(np.float32)
    return out


def compute_metrics(daily_returns, trade_log=None):
    r = pd.Series(daily_returns.sort_values("date")["daily_return"].values).replace([np.inf, -np.inf], np.nan).dropna()
    if len(r) < 2:
        return {k: np.nan for k in ["days","annual_return","annual_volatility","sharpe","sortino","max_drawdown","calmar","win_rate","cumulative_return","trades","turnover","active_rate","average_abs_exposure"]}
    equity = (1 + r).cumprod()
    dd = equity / equity.cummax() - 1
    annual_vol = r.std(ddof=1) * np.sqrt(252)
    sharpe = np.sqrt(252) * r.mean() / r.std(ddof=1) if r.std(ddof=1) > 0 else np.nan
    downside = r[r < 0]
    sortino = np.sqrt(252) * r.mean() / downside.std(ddof=1) if len(downside) > 1 and downside.std(ddof=1) > 0 else np.nan
    ann_ret = equity.iloc[-1] ** (252 / len(r)) - 1
    maxdd = dd.min()
    if trade_log is not None and len(trade_log):
        trades = int(trade_log["trade"].sum()) if "trade" in trade_log else np.nan
        turnover = float(trade_log["abs_position_change"].mean()) if "abs_position_change" in trade_log else np.nan
        pos = trade_log["final_position"] if "final_position" in trade_log else trade_log.get("new_position", pd.Series(np.nan, index=trade_log.index))
        active = float((pos.abs() > 0).mean())
        avgexp = float(pos.abs().mean())
    else:
        trades = turnover = active = avgexp = np.nan
    return {"days": len(r), "annual_return": ann_ret, "annual_volatility": annual_vol, "sharpe": sharpe, "sortino": sortino, "max_drawdown": maxdd, "calmar": ann_ret / abs(maxdd) if maxdd < 0 else np.nan, "win_rate": (r > 0).mean(), "cumulative_return": equity.iloc[-1] - 1, "trades": trades, "turnover": turnover, "active_rate": active, "average_abs_exposure": avgexp}


class DiscretePairEnv(gym.Env):
    def __init__(self, data, features, transaction_cost=TRANSACTION_COST, reward_scale=100.0, reward_config=None, seed=42):
        super().__init__()
        self.data = data.copy()
        self.features = features
        self.transaction_cost = transaction_cost
        self.reward_scale = reward_scale
        self.reward_config = reward_config or {}
        self.groups = [g.sort_values("date").reset_index(drop=True) for _, g in self.data.groupby("pair_id") if len(g) >= 20]
        self.rng = np.random.default_rng(seed)
        self.action_space = spaces.Discrete(3)
        self.observation_space = spaces.Box(low=-10, high=10, shape=(len(features),), dtype=np.float32)
    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        self.group = self.groups[int(self.rng.integers(0, len(self.groups)))]
        self.idx = 0
        self.position = 0
        return self._obs(), {}
    def _obs(self):
        return np.clip(self.group.iloc[self.idx][self.features].values.astype(np.float32), -10, 10)
    @staticmethod
    def action_pos(a):
        return 0 if int(a) == 0 else (1 if int(a) == 1 else -1)
    def step(self, action):
        row = self.group.iloc[self.idx]
        old = self.position
        new = self.action_pos(action)
        base = row["pair_return_long"] if new == 1 else (row["pair_return_short"] if new == -1 else 0.0)
        cost = self.transaction_cost * abs(new - old)
        reward = float(base - cost)
        z = float(row.get("zscore", 0.0))
        if self.reward_config:
            reward -= self.reward_config.get("holding_penalty", 0.0) * abs(new)
            reward -= self.reward_config.get("extra_turnover_penalty", 0.0) * abs(new - old)
            entry_z = self.reward_config.get("entry_z", 0.0)
            if entry_z and new != 0:
                if (new == 1 and z > -entry_z) or (new == -1 and z < entry_z):
                    reward -= self.reward_config.get("wrong_direction_penalty", 0.0)
                if abs(z) < entry_z:
                    reward -= self.reward_config.get("weak_zone_penalty", 0.0)
        self.position = new
        self.idx += 1
        terminated = self.idx >= len(self.group)
        if terminated and self.position != 0:
            reward -= self.transaction_cost * abs(self.position)
            self.position = 0
        obs = np.zeros(len(self.features), dtype=np.float32) if terminated else self._obs()
        return obs, reward * self.reward_scale, terminated, False, {}


class ContinuousPairEnv(gym.Env):
    def __init__(self, data, features, transaction_cost=TRANSACTION_COST, reward_scale=100.0, reward_config=None, min_exposure=0.05, seed=42):
        super().__init__()
        self.data = data.copy()
        self.features = features
        self.transaction_cost = transaction_cost
        self.reward_scale = reward_scale
        self.reward_config = reward_config or {}
        self.min_exposure = min_exposure
        self.groups = [g.sort_values("date").reset_index(drop=True) for _, g in self.data.groupby("pair_id") if len(g) >= 20]
        self.rng = np.random.default_rng(seed)
        self.action_space = spaces.Box(low=-1.0, high=1.0, shape=(1,), dtype=np.float32)
        self.observation_space = spaces.Box(low=-10, high=10, shape=(len(features),), dtype=np.float32)
    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        if seed is not None:
            self.rng = np.random.default_rng(seed)
        self.group = self.groups[int(self.rng.integers(0, len(self.groups)))]
        self.idx = 0
        self.exposure = 0.0
        return self._obs(), {}
    def _obs(self):
        return np.clip(self.group.iloc[self.idx][self.features].values.astype(np.float32), -10, 10)
    def _action(self, action):
        a = float(np.asarray(action).reshape(-1)[0])
        a = float(np.clip(a, -1, 1))
        return 0.0 if abs(a) < self.min_exposure else a
    def step(self, action):
        row = self.group.iloc[self.idx]
        old = self.exposure
        new = self._action(action)
        reward = new * float(row["pair_return_long"]) - self.transaction_cost * abs(new - old)
        z = float(row.get("zscore", 0.0))
        if self.reward_config:
            reward -= self.reward_config.get("holding_penalty", 0.0) * abs(new)
            reward -= self.reward_config.get("extra_turnover_penalty", 0.0) * abs(new - old)
            entry_z = self.reward_config.get("entry_z", 0.0)
            if entry_z and new != 0:
                if (new > 0 and z > -entry_z) or (new < 0 and z < entry_z):
                    reward -= self.reward_config.get("wrong_direction_penalty", 0.0) * abs(new)
                if abs(z) < entry_z:
                    reward -= self.reward_config.get("weak_zone_penalty", 0.0) * abs(new)
        self.exposure = new
        self.idx += 1
        terminated = self.idx >= len(self.group)
        if terminated and self.exposure != 0:
            reward -= self.transaction_cost * abs(self.exposure)
            self.exposure = 0.0
        obs = np.zeros(len(self.features), dtype=np.float32) if terminated else self._obs()
        return obs, reward * self.reward_scale, terminated, False, {}


def evaluate_discrete(model, test_df, scaler, features, model_name, test_year, transaction_cost=TRANSACTION_COST):
    logs = []
    for pair_id, g in test_df.groupby("pair_id"):
        g = g.sort_values("date").reset_index(drop=True)
        x = np.clip(scaler.transform(g[features].values), -10, 10).astype(np.float32)
        pos = 0
        for i, row in g.iterrows():
            action, _ = model.predict(x[i], deterministic=True)
            new = DiscretePairEnv.action_pos(action)
            old = pos
            base = row["pair_return_long"] if new == 1 else (row["pair_return_short"] if new == -1 else 0.0)
            reward = float(base - transaction_cost * abs(new - old))
            final = new
            if i == len(g) - 1 and final != 0:
                reward -= transaction_cost * abs(final)
                final = 0
            logs.append({"test_year": test_year, "model": model_name, "pair_id": pair_id, "date": row["date"], "stock1": row["stock1"], "stock2": row["stock2"], "new_position": new, "final_position": final, "raw_reward": reward, "trade": int(new != old), "abs_position_change": abs(new - old)})
            pos = final
    log = pd.DataFrame(logs)
    daily = log.groupby("date")["raw_reward"].mean().reset_index().rename(columns={"raw_reward": "daily_return"})
    daily["model"] = model_name
    daily["test_year"] = test_year
    return log, daily


def evaluate_continuous(model, test_df, scaler, features, model_name, test_year, transaction_cost=TRANSACTION_COST, min_exposure=0.05):
    logs = []
    for pair_id, g in test_df.groupby("pair_id"):
        g = g.sort_values("date").reset_index(drop=True)
        x = np.clip(scaler.transform(g[features].values), -10, 10).astype(np.float32)
        exp = 0.0
        for i, row in g.iterrows():
            action, _ = model.predict(x[i], deterministic=True)
            new = float(np.clip(np.asarray(action).reshape(-1)[0], -1, 1))
            if abs(new) < min_exposure:
                new = 0.0
            old = exp
            reward = float(new * row["pair_return_long"] - transaction_cost * abs(new - old))
            final = new
            if i == len(g) - 1 and final != 0:
                reward -= transaction_cost * abs(final)
                final = 0.0
            logs.append({"test_year": test_year, "model": model_name, "pair_id": pair_id, "date": row["date"], "stock1": row["stock1"], "stock2": row["stock2"], "action_value": new, "new_position": new, "final_position": final, "raw_reward": reward, "trade": int(abs(new - old) > min_exposure), "abs_position_change": abs(new - old)})
            exp = final
    log = pd.DataFrame(logs)
    daily = log.groupby("date")["raw_reward"].mean().reset_index().rename(columns={"raw_reward": "daily_return"})
    daily["model"] = model_name
    daily["test_year"] = test_year
    return log, daily


def zscore_strategy(test_df, test_year, entry=2.0, exit=0.5, transaction_cost=TRANSACTION_COST):
    logs = []
    for pair_id, g in test_df.groupby("pair_id"):
        g = g.sort_values("date").reset_index(drop=True)
        pos = 0
        for i, row in g.iterrows():
            old = pos
            z = float(row["zscore"])
            if pos == 0:
                if z <= -entry:
                    pos = 1
                elif z >= entry:
                    pos = -1
            elif pos == 1 and abs(z) <= exit:
                pos = 0
            elif pos == -1 and abs(z) <= exit:
                pos = 0
            base = row["pair_return_long"] if pos == 1 else (row["pair_return_short"] if pos == -1 else 0.0)
            reward = float(base - transaction_cost * abs(pos - old))
            final = pos
            if i == len(g) - 1 and final != 0:
                reward -= transaction_cost * abs(final)
                final = 0
            logs.append({"test_year": test_year, "model": "ZScore", "pair_id": pair_id, "date": row["date"], "stock1": row["stock1"], "stock2": row["stock2"], "new_position": pos, "final_position": final, "raw_reward": reward, "trade": int(pos != old), "abs_position_change": abs(pos - old)})
            pos = final
    log = pd.DataFrame(logs)
    daily = log.groupby("date")["raw_reward"].mean().reset_index().rename(columns={"raw_reward": "daily_return"})
    daily["model"] = "ZScore"
    daily["test_year"] = test_year
    return log, daily
