"""Build pair-date RL datasets from dynamic pairs, clean panel, and regime features."""
from __future__ import annotations
import argparse
import numpy as np
import pandas as pd
from config import PROCESSED_DIR, TRAIN_YEARS

FEATURES = [
    "zscore", "spread", "spread_mean_60", "spread_std_60", "spread_vol_20",
    "pair_return_current", "pair_vol_20", "return_1", "return_2", "vol_20_1", "vol_20_2",
    "log_volume_ratio", "log_market_cap_ratio", "log_adv_ratio", "vix", "spx_return", "spx_vol_20",
    "us10y", "vix_change", "us10y_change", "regime_code"
]


def safe_log_ratio(a, b):
    ratio = a / b
    ratio = ratio.replace([np.inf, -np.inf], np.nan)
    ratio = ratio.where(ratio > 0)
    return np.log(ratio)


def build_pair_df(pair, panel_dict, regime):
    year = int(pair["test_year"])
    s1, s2 = str(pair["stock1"]), str(pair["stock2"])
    if s1 not in panel_dict or s2 not in panel_dict:
        return pd.DataFrame()
    train_start = pd.Timestamp(pair.get("train_start", f"{year - TRAIN_YEARS}-01-01"))
    train_end = pd.Timestamp(pair.get("train_end", f"{year - 1}-12-31"))
    test_start = pd.Timestamp(f"{year}-01-01")
    test_end = pd.Timestamp(f"{year}-12-31")
    beta = float(pair.get("hedge_beta", 1.0))
    alpha = float(pair.get("hedge_alpha", 0.0))
    if not np.isfinite(beta) or beta <= 0:
        beta = 1.0
    a = panel_dict[s1].copy()
    b = panel_dict[s2].copy()
    a = a[(a["date"] >= train_start) & (a["date"] <= test_end)].rename(columns={"px_last":"px_last_1", "px_volume":"px_volume_1", "cur_mkt_cap":"cur_mkt_cap_1", "return":"return_1", "adv_60":"adv_60_1", "vol_20":"vol_20_1"})
    b = b[(b["date"] >= train_start) & (b["date"] <= test_end)].rename(columns={"px_last":"px_last_2", "px_volume":"px_volume_2", "cur_mkt_cap":"cur_mkt_cap_2", "return":"return_2", "adv_60":"adv_60_2", "vol_20":"vol_20_2"})
    df = a.merge(b, on="date", how="inner").sort_values("date")
    if len(df) < 100:
        return pd.DataFrame()
    df = pd.merge_asof(df.sort_values("date"), regime.sort_values("date"), on="date", direction="backward")
    df["log_price_1"] = np.log(df["px_last_1"])
    df["log_price_2"] = np.log(df["px_last_2"])
    df["spread"] = df["log_price_1"] - (alpha + beta * df["log_price_2"])
    df["spread_mean_60"] = df["spread"].rolling(60, min_periods=30).mean()
    df["spread_std_60"] = df["spread"].rolling(60, min_periods=30).std()
    df["zscore"] = (df["spread"] - df["spread_mean_60"]) / df["spread_std_60"]
    df["spread_vol_20"] = df["spread"].diff().rolling(20, min_periods=10).std()
    gross = 1.0 + abs(beta)
    df["pair_return_current"] = (df["return_1"] - beta * df["return_2"]) / gross
    df["pair_vol_20"] = df["pair_return_current"].rolling(20, min_periods=10).std() * np.sqrt(252)
    df["stock1_return_fwd"] = df["return_1"].shift(-1)
    df["stock2_return_fwd"] = df["return_2"].shift(-1)
    df["reward_date"] = df["date"].shift(-1)
    df["pair_return_long"] = (df["stock1_return_fwd"] - beta * df["stock2_return_fwd"]) / gross
    df["pair_return_short"] = -df["pair_return_long"]
    df["log_volume_ratio"] = safe_log_ratio(df["px_volume_1"], df["px_volume_2"])
    df["log_market_cap_ratio"] = safe_log_ratio(df["cur_mkt_cap_1"], df["cur_mkt_cap_2"])
    df["log_adv_ratio"] = safe_log_ratio(df["adv_60_1"], df["adv_60_2"])
    df["test_year"] = year
    df["stock1"], df["stock2"] = s1, s2
    df["sector"] = pair.get("sector", "Unknown")
    df["hedge_alpha"], df["hedge_beta"] = alpha, beta
    df["pair_id"] = f"{year}::{s1}::{s2}"
    df["split"] = "drop"
    df.loc[(df["date"] >= train_start) & (df["reward_date"] <= train_end), "split"] = "train"
    df.loc[(df["date"] >= test_start) & (df["reward_date"] <= test_end), "split"] = "test"
    for col in ["corr", "coint_pvalue", "half_life", "score", "min_dollar_volume"]:
        df[col] = pair.get(col, np.nan)
    required = FEATURES + ["pair_return_long", "pair_return_short"]
    df = df.replace([np.inf, -np.inf], np.nan).dropna(subset=required)
    keep = ["pair_id", "test_year", "split", "date", "reward_date", "stock1", "stock2", "sector", "hedge_alpha", "hedge_beta", "corr", "coint_pvalue", "half_life", "score"] + FEATURES + ["pair_return_long", "pair_return_short"]
    return df[[c for c in keep if c in df.columns]]


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--test-year", type=int, default=0)
    parser.add_argument("--max-pairs", type=int, default=0)
    args = parser.parse_args()
    out_dir = PROCESSED_DIR / "rl_pair_dataset"
    out_dir.mkdir(parents=True, exist_ok=True)
    pairs = pd.read_csv(PROCESSED_DIR / "dynamic_pairs_walkforward.csv")
    if args.test_year:
        pairs = pairs[pairs["test_year"] == args.test_year]
    if args.max_pairs:
        pairs = pairs.sort_values(["test_year", "score"], ascending=[True, False]).groupby("test_year").head(args.max_pairs)
    tickers = set(pairs["stock1"].astype(str)).union(set(pairs["stock2"].astype(str)))
    panel = pd.read_parquet(PROCESSED_DIR / "clean_stock_panel.parquet")
    panel["date"] = pd.to_datetime(panel["date"])
    panel = panel[panel["ticker"].isin(tickers)].copy()
    panel_dict = {t: g.sort_values("date").reset_index(drop=True) for t, g in panel.groupby("ticker")}
    regime = pd.read_parquet(PROCESSED_DIR / "market_regime_features.parquet")
    regime["date"] = pd.to_datetime(regime["date"])
    pd.DataFrame({"feature": FEATURES}).to_csv(out_dir / "feature_columns.csv", index=False)
    manifest = []
    for year, pairs_y in pairs.groupby("test_year"):
        frames = []
        print("Building RL dataset for", year, "pairs", len(pairs_y))
        for _, pair in pairs_y.iterrows():
            df = build_pair_df(pair, panel_dict, regime)
            if not df.empty:
                frames.append(df)
                manifest.append({"test_year": year, "pair_id": df["pair_id"].iloc[0], "rows": len(df), "train": int((df["split"] == "train").sum()), "test": int((df["split"] == "test").sum())})
        if not frames:
            continue
        year_df = pd.concat(frames, ignore_index=True)
        year_df.to_parquet(out_dir / f"rl_pairs_all_{year}.parquet", index=False)
        year_df[year_df["split"] == "train"].to_parquet(out_dir / f"rl_pairs_train_{year}.parquet", index=False)
        year_df[year_df["split"] == "test"].to_parquet(out_dir / f"rl_pairs_test_{year}.parquet", index=False)
    pd.DataFrame(manifest).to_csv(out_dir / "rl_pair_dataset_manifest.csv", index=False)
    print("Saved RL pair datasets.")

if __name__ == "__main__":
    main()
