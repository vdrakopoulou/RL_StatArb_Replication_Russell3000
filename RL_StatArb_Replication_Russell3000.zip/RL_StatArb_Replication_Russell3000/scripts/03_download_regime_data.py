"""Download market-regime variables from Bloomberg."""
import pandas as pd
from xbbg import blp
from config import RAW_DIR, START_DATE, END_DATE, REGIME_TICKERS

OUT_DIR = RAW_DIR / "regime_data"
OUT_DIR.mkdir(parents=True, exist_ok=True)

def normalize(raw, name):
    df = raw.to_pandas() if hasattr(raw, "to_pandas") else raw
    df = pd.DataFrame(df)
    if {"date", "field", "value"}.issubset(df.columns):
        df = df[df["field"].astype(str).str.upper() == "PX_LAST"][["date", "value"]].rename(columns={"value": name})
    else:
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = [c[-1] if isinstance(c, tuple) else c for c in df.columns]
        df = df.reset_index().rename(columns={"index": "date"})
        value_col = "PX_LAST" if "PX_LAST" in df.columns else [c for c in df.columns if c != "date"][-1]
        df = df[["date", value_col]].rename(columns={value_col: name})
    return df

def main():
    frames = []
    for ticker, name in REGIME_TICKERS.items():
        print("Downloading", ticker)
        raw = blp.bdh(ticker, "PX_LAST", start_date=START_DATE, end_date=END_DATE)
        df = normalize(raw, name)
        df.to_parquet(OUT_DIR / f"{name}.parquet", index=False)
        frames.append(df)
    regime = frames[0]
    for f in frames[1:]:
        regime = regime.merge(f, on="date", how="outer")
    regime = regime.sort_values("date")
    regime.to_parquet(OUT_DIR / "market_regime_raw.parquet", index=False)
    print("Saved", OUT_DIR)

if __name__ == "__main__":
    main()
