"""Train and evaluate discrete-action PPO and A2C plus z-score benchmark."""
from __future__ import annotations
import argparse
import pandas as pd
from stable_baselines3 import PPO, A2C
from stable_baselines3.common.vec_env import DummyVecEnv
from config import PROCESSED_DIR, RESULTS_DIR, MODEL_DIR, TRANSACTION_COST
from rl_helpers import FEATURES, find_years, clean_dataset, limit_pairs, scale_fit, scale_df, DiscretePairEnv, evaluate_discrete, zscore_strategy, compute_metrics


def train_model(name, train_scaled, features, timesteps, reward_scale, seed):
    env = DummyVecEnv([lambda: DiscretePairEnv(train_scaled, features, transaction_cost=TRANSACTION_COST, reward_scale=reward_scale, seed=seed)])
    if name == "PPO":
        model = PPO("MlpPolicy", env, learning_rate=3e-4, n_steps=2048, batch_size=256, gamma=0.99, gae_lambda=0.95, ent_coef=0.001, verbose=0, seed=seed)
    elif name == "A2C":
        model = A2C("MlpPolicy", env, learning_rate=7e-4, n_steps=64, gamma=0.99, gae_lambda=0.95, ent_coef=0.001, verbose=0, seed=seed)
    else:
        raise ValueError(name)
    model.learn(total_timesteps=timesteps)
    return model


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--test-year", type=int, default=0)
    parser.add_argument("--max-pairs", type=int, default=0)
    parser.add_argument("--timesteps", type=int, default=100000)
    parser.add_argument("--reward-scale", type=float, default=100.0)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--models", nargs="+", default=["PPO", "A2C"])
    args = parser.parse_args()
    years = [args.test_year] if args.test_year else find_years()
    rows, daily_all = [], []
    for year in years:
        print("Year", year)
        train_df = pd.read_parquet(PROCESSED_DIR / "rl_pair_dataset" / f"rl_pairs_train_{year}.parquet")
        test_df = pd.read_parquet(PROCESSED_DIR / "rl_pair_dataset" / f"rl_pairs_test_{year}.parquet")
        features = [c for c in FEATURES if c in train_df.columns and c in test_df.columns]
        train_df = limit_pairs(clean_dataset(train_df, features), args.max_pairs)
        test_df = clean_dataset(test_df, features)
        test_df = test_df[test_df["pair_id"].isin(train_df["pair_id"].unique())].copy()
        scaler = scale_fit(train_df, features, MODEL_DIR / f"scaler_discrete_{year}.joblib")
        train_scaled = scale_df(train_df, scaler, features)
        zlog, zdaily = zscore_strategy(test_df, year)
        zmetrics = compute_metrics(zdaily, zlog)
        zlog.to_csv(RESULTS_DIR / f"trade_log_ZScore_{year}.csv", index=False)
        zdaily.to_csv(RESULTS_DIR / f"daily_returns_ZScore_{year}.csv", index=False)
        rows.append({"test_year": year, "model": "ZScore", "reward_variant": "benchmark", **zmetrics})
        daily_all.append(zdaily)
        for name in [m.upper() for m in args.models]:
            print("Training", name, year)
            model = train_model(name, train_scaled, features, args.timesteps, args.reward_scale, args.seed)
            model.save(MODEL_DIR / f"{name}_{year}")
            log, daily = evaluate_discrete(model, test_df, scaler, features, name, year)
            metrics = compute_metrics(daily, log)
            log.to_csv(RESULTS_DIR / f"trade_log_{name}_{year}.csv", index=False)
            daily.to_csv(RESULTS_DIR / f"daily_returns_{name}_{year}.csv", index=False)
            rows.append({"test_year": year, "model": name, "reward_variant": "discrete_baseline", **metrics})
            daily_all.append(daily)
        pd.DataFrame(rows).to_csv(RESULTS_DIR / "rolling_walkforward_rl_results.csv", index=False)
        pd.concat(daily_all, ignore_index=True).to_csv(RESULTS_DIR / "daily_returns_by_model.csv", index=False)
    print("Saved baseline discrete results.")

if __name__ == "__main__":
    main()
