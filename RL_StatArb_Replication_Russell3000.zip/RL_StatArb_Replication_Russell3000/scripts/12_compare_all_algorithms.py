"""Combine ZScore, PPO, A2C, directional A2C, SAC, and TD3 results."""
from __future__ import annotations
import os
import numpy as np
import pandas as pd
from config import RESULTS_DIR, TABLE_DIR

METRICS = ["annual_return", "annual_volatility", "sharpe", "sortino", "max_drawdown", "calmar", "win_rate", "trades", "turnover", "active_rate", "average_abs_exposure"]


def load_if_exists(path):
    return pd.read_csv(path) if path.exists() else None


def main():
    frames = []
    base = load_if_exists(RESULTS_DIR / "rolling_walkforward_rl_results.csv")
    if base is not None:
        base["model_variant"] = base["model"].map({"ZScore": "ZScore", "PPO": "PPO_discrete", "A2C": "A2C_discrete"})
        frames.append(base)
    a2c_dir = load_if_exists(RESULTS_DIR / "directional_reward_results.csv")
    if a2c_dir is not None:
        a2c_dir = a2c_dir[(a2c_dir["model"].astype(str).str.upper() == "A2C") & (a2c_dir["reward_variant"].astype(str) == "directional_strong")].copy()
        a2c_dir["model_variant"] = "A2C_directional_strong"
        frames.append(a2c_dir)
    sac = load_if_exists(RESULTS_DIR / "sac_continuous_results.csv")
    if sac is not None:
        sac["model_variant"] = "SAC_" + sac["reward_variant"].astype(str)
        frames.append(sac)
    td3 = load_if_exists(RESULTS_DIR / "td3_continuous_results.csv")
    if td3 is not None:
        td3["model_variant"] = "TD3_" + td3["reward_variant"].astype(str)
        frames.append(td3)
    if not frames:
        raise FileNotFoundError("No result files found.")
    combined = pd.concat(frames, ignore_index=True)
    combined["test_year"] = pd.to_numeric(combined["test_year"], errors="coerce")
    combined = combined.dropna(subset=["test_year", "model_variant"])
    combined["test_year"] = combined["test_year"].astype(int)
    for m in METRICS:
        if m not in combined.columns:
            combined[m] = np.nan
        combined[m] = pd.to_numeric(combined[m], errors="coerce")
    combined = combined.sort_values(["test_year", "model_variant"])
    combined.to_csv(TABLE_DIR / "all_algorithm_results_combined.csv", index=False)
    summary_mean = combined.groupby("model_variant")[METRICS].mean().reset_index().sort_values("sharpe", ascending=False)
    summary_median = combined.groupby("model_variant")[METRICS].median().reset_index().sort_values("sharpe", ascending=False)
    summary_std = combined.groupby("model_variant")[METRICS].std().reset_index()
    best = combined.sort_values(["test_year", "sharpe"], ascending=[True, False]).groupby("test_year").head(1)
    wins = best["model_variant"].value_counts().rename_axis("model_variant").reset_index(name="sharpe_wins")
    summary_mean.to_csv(TABLE_DIR / "summary_mean_all_algorithms.csv", index=False)
    summary_median.to_csv(TABLE_DIR / "summary_median_all_algorithms.csv", index=False)
    summary_std.to_csv(TABLE_DIR / "summary_std_all_algorithms.csv", index=False)
    best.to_csv(TABLE_DIR / "best_model_by_year_all_algorithms.csv", index=False)
    wins.to_csv(TABLE_DIR / "win_counts_all_algorithms.csv", index=False)
    excel = TABLE_DIR / "final_four_rl_algorithms_comparison.xlsx"
    with pd.ExcelWriter(excel, engine="openpyxl") as writer:
        combined.to_excel(writer, sheet_name="Combined Results", index=False)
        summary_mean.to_excel(writer, sheet_name="Mean Summary", index=False)
        summary_median.to_excel(writer, sheet_name="Median Summary", index=False)
        summary_std.to_excel(writer, sheet_name="Std Summary", index=False)
        best.to_excel(writer, sheet_name="Best by Sharpe", index=False)
        wins.to_excel(writer, sheet_name="Win Counts", index=False)
    print(summary_mean[["model_variant", "annual_return", "sharpe", "sortino", "max_drawdown", "calmar", "active_rate"]].to_string(index=False))
    print("Saved", excel)

if __name__ == "__main__":
    main()
