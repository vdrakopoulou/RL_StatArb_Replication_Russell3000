"""Dynamic sector-aware pair selection using correlation, cointegration, half-life, and liquidity ranking."""
from __future__ import annotations
import argparse
import warnings
from itertools import combinations
import numpy as np
import pandas as pd
from statsmodels.tsa.stattools import coint
from config import PROCESSED_DIR, TRAIN_YEARS, TEST_START_YEAR, TEST_END_YEAR, TOP_N_PAIRS, CORR_THRESHOLD, COINT_THRESHOLD, MAX_HALF_LIFE
warnings.filterwarnings("ignore")


def estimate_half_life(spread):
    s = pd.Series(spread).dropna()
    if len(s) < 50:
        return np.nan
    lag = s.shift(1)
    delta = s - lag
    df = pd.concat([lag, delta], axis=1).dropna()
    if df.iloc[:, 0].std() == 0:
        return np.nan
    beta = np.polyfit(df.iloc[:, 0], df.iloc[:, 1], 1)[0]
    return np.nan if beta >= 0 else float(-np.log(2) / beta)


def select_pairs_for_year(panel, universe, test_year, min_obs=500, top_n=TOP_N_PAIRS):
    train_start = pd.Timestamp(f"{test_year - TRAIN_YEARS}-01-01")
    train_end = pd.Timestamp(f"{test_year - 1}-12-31")
    train = panel[(panel["date"] >= train_start) & (panel["date"] <= train_end) & (panel["ticker"].isin(universe["ticker"]))].copy()
    prices = train.pivot_table(index="date", columns="ticker", values="px_last", aggfunc="last").sort_index()
    valid = prices.columns[prices.notna().sum() >= int(len(prices) * 0.70)]
    prices = prices[valid].ffill(limit=5)
    log_prices = np.log(prices)
    returns = prices.pct_change()
    liquidity = train.groupby("ticker")["dollar_volume"].median().to_dict()
    universe = universe[universe["ticker"].isin(valid)].copy()
    candidates = []
    for sector, group in universe.groupby("sector_final"):
        tickers = sorted(group["ticker"].unique())
        if len(tickers) < 2:
            continue
        corr = returns[tickers].corr(min_periods=min_obs)
        vals = corr.values
        cols = corr.columns.tolist()
        ii, jj = np.where(np.triu(vals, k=1) >= CORR_THRESHOLD)
        for i, j in zip(ii, jj):
            a, b = cols[i], cols[j]
            joined = log_prices[[a, b]].dropna()
            if len(joined) < min_obs:
                continue
            try:
                stat, pvalue, _ = coint(joined[a], joined[b])
                if not np.isfinite(pvalue) or pvalue > COINT_THRESHOLD:
                    continue
                beta, alpha = np.polyfit(joined[b].values, joined[a].values, 1)
                if beta <= 0 or not np.isfinite(beta):
                    continue
                spread = joined[a].values - (alpha + beta * joined[b].values)
                hl = estimate_half_life(spread)
                if not np.isfinite(hl) or hl <= 1 or hl > MAX_HALF_LIFE:
                    continue
                min_dv = min(liquidity.get(a, np.nan), liquidity.get(b, np.nan))
                if not np.isfinite(min_dv):
                    continue
                candidates.append({
                    "test_year": test_year, "train_start": train_start.date(), "train_end": train_end.date(),
                    "sector": sector, "stock1": a, "stock2": b, "corr": vals[i, j],
                    "coint_pvalue": pvalue, "coint_stat": stat, "hedge_alpha": alpha, "hedge_beta": beta,
                    "half_life": hl, "min_dollar_volume": min_dv, "obs": len(joined)
                })
            except Exception:
                continue
    pairs = pd.DataFrame(candidates)
    if pairs.empty:
        return pairs
    pairs["liquidity_rank"] = pairs["min_dollar_volume"].rank(pct=True)
    pairs["corr_rank"] = pairs["corr"].rank(pct=True)
    pairs["coint_rank"] = (1 - pairs["coint_pvalue"]).rank(pct=True)
    pairs["half_life_rank"] = (-pairs["half_life"]).rank(pct=True)
    pairs["score"] = 0.35*pairs["corr_rank"] + 0.35*pairs["coint_rank"] + 0.15*pairs["half_life_rank"] + 0.15*pairs["liquidity_rank"]
    return pairs.sort_values("score", ascending=False).head(top_n)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--test-year", type=int, default=0)
    parser.add_argument("--top-n", type=int, default=TOP_N_PAIRS)
    args = parser.parse_args()
    panel = pd.read_parquet(PROCESSED_DIR / "clean_stock_panel.parquet")
    panel["date"] = pd.to_datetime(panel["date"])
    universe = pd.read_csv(PROCESSED_DIR / "tradable_universe.csv")
    years = [args.test_year] if args.test_year else list(range(TEST_START_YEAR, TEST_END_YEAR + 1))
    frames = []
    summary = []
    for year in years:
        print("Selecting pairs for", year)
        pairs = select_pairs_for_year(panel, universe, year, top_n=args.top_n)
        out_file = PROCESSED_DIR / f"dynamic_pairs_test_year_{year}.csv"
        pairs.to_csv(out_file, index=False)
        frames.append(pairs)
        summary.append({"test_year": year, "selected_pairs": len(pairs), "avg_corr": pairs["corr"].mean() if not pairs.empty else np.nan})
    all_pairs = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
    all_pairs.to_csv(PROCESSED_DIR / "dynamic_pairs_walkforward.csv", index=False)
    pd.DataFrame(summary).to_csv(PROCESSED_DIR / "dynamic_pair_selection_summary.csv", index=False)
    print("Saved dynamic pair files.")

if __name__ == "__main__":
    main()
