"""Build clean stock panel, tradable universe, and regime features."""
from __future__ import annotations
import glob
from pathlib import Path
import numpy as np
import pandas as pd
from config import RAW_DIR, PROCESSED_DIR, PRICE_MIN, MARKET_CAP_MIN, ADV_MIN, MIN_OBS

STOCK_DIR = RAW_DIR / "russell3000_ohlcv"
REGIME_DIR = RAW_DIR / "regime_data"

RENAME = {
    "PX_OPEN": "px_open", "PX_HIGH": "px_high", "PX_LOW": "px_low",
    "PX_LAST": "px_last", "PX_VOLUME": "px_volume", "CUR_MKT_CAP": "cur_mkt_cap"
}


def standardize_stock_file(file: Path) -> pd.DataFrame:
    df = pd.read_parquet(file)
    df = pd.DataFrame(df)
    if df.empty:
        return df
    if {"date", "field", "value"}.issubset(set(df.columns)):
        ticker = df["ticker"].iloc[0] if "ticker" in df.columns else file.stem.replace("_", " ")
        df = df.pivot_table(index="date", columns="field", values="value", aggfunc="last").reset_index()
        df.columns.name = None
        df["ticker"] = ticker
    if "date" not in df.columns and "index" in df.columns:
        df = df.rename(columns={"index": "date"})
    df = df.rename(columns=RENAME)
    if "ticker" not in df.columns:
        df["ticker"] = file.stem.replace("_", " ").replace(" Equity", " Equity")
    keep = [c for c in ["date", "ticker", "px_open", "px_high", "px_low", "px_last", "px_volume", "cur_mkt_cap"] if c in df.columns]
    df = df[keep].copy()
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    for c in ["px_open", "px_high", "px_low", "px_last", "px_volume", "cur_mkt_cap"]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce")
    df = df.dropna(subset=["date", "ticker", "px_last"])
    return df[df["px_last"] > 0]


def build_clean_panel() -> pd.DataFrame:
    files = sorted(STOCK_DIR.glob("*.parquet"))
    frames, inventory = [], []
    print("Stock files found:", len(files))
    for i, file in enumerate(files, start=1):
        if i % 100 == 0:
            print(f"Reading {i}/{len(files)}")
        try:
            df = standardize_stock_file(file)
            if df.empty:
                inventory.append({"file": file.name, "rows": 0, "status": "empty"})
                continue
            inventory.append({"file": file.name, "ticker": df["ticker"].iloc[0], "rows": len(df), "first_date": df["date"].min(), "last_date": df["date"].max(), "status": "ok"})
            frames.append(df)
        except Exception as e:
            inventory.append({"file": file.name, "status": "error", "error": str(e)})
    panel = pd.concat(frames, ignore_index=True).sort_values(["ticker", "date"])
    panel["return"] = panel.groupby("ticker")["px_last"].pct_change()
    panel["dollar_volume"] = panel["px_last"] * panel["px_volume"]
    panel["adv_60"] = panel.groupby("ticker")["dollar_volume"].transform(lambda x: x.rolling(60, min_periods=20).mean())
    panel["vol_20"] = panel.groupby("ticker")["return"].transform(lambda x: x.rolling(20, min_periods=10).std() * np.sqrt(252))
    panel.to_parquet(PROCESSED_DIR / "clean_stock_panel.parquet", index=False)
    pd.DataFrame(inventory).to_csv(PROCESSED_DIR / "ohlcv_inventory.csv", index=False)
    print("Panel rows:", len(panel), "tickers:", panel["ticker"].nunique())
    return panel


def build_tradable_universe(panel: pd.DataFrame) -> pd.DataFrame:
    latest = panel.sort_values(["ticker", "date"]).groupby("ticker").tail(1).copy()
    hist = panel.groupby("ticker").agg(first_date=("date", "min"), last_date=("date", "max"), obs_count=("date", "count")).reset_index()
    latest = latest.merge(hist, on="ticker", how="left")
    cap_threshold = MARKET_CAP_MIN
    if latest["cur_mkt_cap"].median(skipna=True) < 1_000_000:
        cap_threshold = MARKET_CAP_MIN / 1_000_000
    tradable = latest[(latest["px_last"] > PRICE_MIN) & (latest["cur_mkt_cap"] > cap_threshold) & (latest["adv_60"] > ADV_MIN) & (latest["obs_count"] >= MIN_OBS)].copy()
    meta_file = RAW_DIR / "russell3000_metadata.csv"
    if meta_file.exists():
        meta = pd.read_csv(meta_file)
        tradable = tradable.merge(meta, on="ticker", how="left")
    if "GICS_SECTOR_NAME" in tradable.columns:
        tradable["sector_final"] = tradable["GICS_SECTOR_NAME"]
    elif "INDUSTRY_SECTOR" in tradable.columns:
        tradable["sector_final"] = tradable["INDUSTRY_SECTOR"]
    else:
        tradable["sector_final"] = "Unknown"
    tradable = tradable.dropna(subset=["sector_final"])
    tradable.to_csv(PROCESSED_DIR / "tradable_universe.csv", index=False)
    print("Tradable universe:", len(tradable))
    return tradable


def read_regime_file(path: Path, name: str) -> pd.DataFrame:
    df = pd.read_parquet(path)
    df = pd.DataFrame(df)
    if {"date", "field", "value"}.issubset(set(df.columns)):
        df = df[df["field"].astype(str).str.upper() == "PX_LAST"][["date", "value"]].rename(columns={"value": name})
    else:
        if "date" not in df.columns and "index" in df.columns:
            df = df.rename(columns={"index": "date"})
        value_cols = [c for c in df.columns if c not in ["date", "ticker"]]
        value_col = "PX_LAST" if "PX_LAST" in value_cols else value_cols[-1]
        df = df[["date", value_col]].rename(columns={value_col: name})
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df[name] = pd.to_numeric(df[name], errors="coerce")
    return df.dropna()


def build_regime_features() -> pd.DataFrame:
    frames = []
    for name in ["spx", "vix", "us10y"]:
        path = REGIME_DIR / f"{name}.parquet"
        if path.exists():
            frames.append(read_regime_file(path, name))
    if not frames:
        print("No regime data found; skipping regime features.")
        return pd.DataFrame()
    regime = frames[0]
    for f in frames[1:]:
        regime = regime.merge(f, on="date", how="outer")
    regime = regime.sort_values("date")
    for c in ["spx", "vix", "us10y"]:
        if c in regime.columns:
            regime[c] = regime[c].ffill()
    regime["spx_return"] = regime["spx"].pct_change()
    regime["spx_vol_20"] = regime["spx_return"].rolling(20, min_periods=10).std() * np.sqrt(252)
    regime["vix_change"] = regime["vix"].diff()
    regime["us10y_change"] = regime["us10y"].diff()
    regime["regime_code"] = np.select([regime["vix"] < 15, (regime["vix"] >= 15) & (regime["vix"] < 25), regime["vix"] >= 25], [0, 1, 2], default=np.nan)
    regime = regime.dropna(subset=["spx_return", "spx_vol_20", "vix", "us10y"])
    regime.to_parquet(PROCESSED_DIR / "market_regime_features.parquet", index=False)
    regime.to_csv(PROCESSED_DIR / "market_regime_features.csv", index=False)
    print("Regime rows:", len(regime))
    return regime


def main():
    panel = build_clean_panel()
    build_tradable_universe(panel)
    build_regime_features()

if __name__ == "__main__":
    main()
