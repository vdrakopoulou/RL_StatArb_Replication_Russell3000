"""Train continuous-action TD3 for position-sized statistical arbitrage."""
from __future__ import annotations
import argparse
import numpy as np
import pandas as pd
from stable_baselines3 import TD3
from stable_baselines3.common.vec_env import DummyVecEnv
from stable_baselines3.common.noise import NormalActionNoise
from config import PROCESSED_DIR, RESULTS_DIR, MODEL_DIR, TRANSACTION_COST
from rl_helpers import FEATURES, find_years, clean_dataset, limit_pairs, scale_fit, scale_df, ContinuousPairEnv, evaluate_continuous, compute_metrics

VARIANTS = {
    "continuous_baseline": {},
    "continuous_directional_medium": {"holding_penalty": 0.00002, "extra_turnover_penalty": 0.00025, "weak_zone_penalty": 0.00010, "wrong_direction_penalty": 0.00050, "entry_z": 1.25},
    "continuous_directional_strong": {"holding_penalty": 0.00005, "extra_turnover_penalty": 0.00050, "weak_zone_penalty": 0.00030, "wrong_direction_penalty": 0.00100, "entry_z": 1.50},
}


def load_existing(resume):
    file = RESULTS_DIR / "td3_continuous_results.csv"
    return pd.read_csv(file) if resume and file.exists() else pd.DataFrame()


def skip_existing(existing, year, variant):
    if existing.empty:
        return False
    return len(existing[(existing["test_year"].astype(int) == int(year)) & (existing["reward_variant"].astype(str) == variant)]) > 0


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--test-year", type=int, default=0)
    parser.add_argument("--max-pairs", type=int, default=100)
    parser.add_argument("--timesteps", type=int, default=100000)
    parser.add_argument("--reward-scale", type=float, default=100.0)
    parser.add_argument("--min-exposure", type=float, default=0.05)
    parser.add_argument("--action-noise-sigma", type=float, default=0.10)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--variants", nargs="+", default=["continuous_baseline", "continuous_directional_medium", "continuous_directional_strong"])
    args = parser.parse_args()
    years = [args.test_year] if args.test_year else find_years()
    existing = load_existing(args.resume)
    rows = []
    daily_all = []
    for year in years:
        train_df = pd.read_parquet(PROCESSED_DIR / "rl_pair_dataset" / f"rl_pairs_train_{year}.parquet")
        test_df = pd.read_parquet(PROCESSED_DIR / "rl_pair_dataset" / f"rl_pairs_test_{year}.parquet")
        features = [c for c in FEATURES if c in train_df.columns and c in test_df.columns]
        train_df = limit_pairs(clean_dataset(train_df, features), args.max_pairs)
        test_df = clean_dataset(test_df, features)
        test_df = test_df[test_df["pair_id"].isin(train_df["pair_id"].unique())].copy()
        scaler = scale_fit(train_df, features, MODEL_DIR / f"scaler_TD3_{year}.joblib")
        train_scaled = scale_df(train_df, scaler, features)
        for variant in args.variants:
            if skip_existing(existing, year, variant):
                print("Skipping existing", year, variant)
                continue
            config = VARIANTS[variant]
            env = DummyVecEnv([lambda: ContinuousPairEnv(train_scaled, features, transaction_cost=TRANSACTION_COST, reward_scale=args.reward_scale, reward_config=config, min_exposure=args.min_exposure, seed=args.seed)])
            noise = NormalActionNoise(mean=np.zeros(1), sigma=args.action_noise_sigma * np.ones(1))
            model = TD3("MlpPolicy", env, learning_rate=3e-4, buffer_size=200000, learning_starts=1000, batch_size=256, tau=0.005, gamma=0.99, train_freq=(1, "step"), gradient_steps=1, action_noise=noise, policy_delay=2, target_policy_noise=0.2, target_noise_clip=0.5, verbose=0, seed=args.seed)
            model.learn(total_timesteps=args.timesteps)
            model.save(MODEL_DIR / f"TD3_{variant}_{year}")
            log, daily = evaluate_continuous(model, test_df, scaler, features, "TD3", year, min_exposure=args.min_exposure)
            metrics = compute_metrics(daily, log)
            log.to_csv(RESULTS_DIR / f"trade_log_TD3_{variant}_{year}.csv", index=False)
            daily.to_csv(RESULTS_DIR / f"daily_returns_TD3_{variant}_{year}.csv", index=False)
            row = {"test_year": year, "model": "TD3", "reward_variant": variant, **config, **metrics}
            rows.append(row)
            daily_all.append(daily.assign(reward_variant=variant))
            combined = pd.concat([existing, pd.DataFrame(rows)], ignore_index=True) if not existing.empty else pd.DataFrame(rows)
            combined.drop_duplicates(subset=["test_year", "model", "reward_variant"], keep="last").to_csv(RESULTS_DIR / "td3_continuous_results.csv", index=False)
            if daily_all:
                pd.concat(daily_all, ignore_index=True).to_csv(RESULTS_DIR / "td3_continuous_daily_returns.csv", index=False)
    print("Saved TD3 continuous results.")

if __name__ == "__main__":
    main()
