"""Paired statistical tests across matched walk-forward years."""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy import stats
from config import TABLE_DIR

METRICS = ["annual_return", "sharpe", "sortino", "max_drawdown", "calmar", "trades", "turnover", "active_rate", "average_abs_exposure"]


def boot_ci(values, n=10000, alpha=0.05, seed=42):
    vals = np.asarray(values, dtype=float)
    vals = vals[np.isfinite(vals)]
    if len(vals) < 2:
        return np.nan, np.nan
    rng = np.random.default_rng(seed)
    means = [rng.choice(vals, len(vals), replace=True).mean() for _ in range(n)]
    return np.percentile(means, 100*alpha/2), np.percentile(means, 100*(1-alpha/2))


def paired(df, a, b, metric):
    da = df[df["model_variant"] == a][["test_year", metric]]
    db = df[df["model_variant"] == b][["test_year", metric]]
    m = da.merge(db, on="test_year", suffixes=("_a", "_b")).dropna()
    if len(m) < 2:
        return None
    x = m[f"{metric}_a"].astype(float).values
    y = m[f"{metric}_b"].astype(float).values
    diff = x - y
    t_stat, t_p = stats.ttest_rel(x, y, nan_policy="omit")
    try:
        w_stat, w_p = stats.wilcoxon(diff) if not np.allclose(diff, 0) else (np.nan, np.nan)
    except Exception:
        w_stat, w_p = np.nan, np.nan
    lo, hi = boot_ci(diff)
    return {"model_a": a, "model_b": b, "metric": metric, "n_years": len(diff), "mean_model_a": np.mean(x), "mean_model_b": np.mean(y), "mean_diff_a_minus_b": np.mean(diff), "bootstrap_ci_low": lo, "bootstrap_ci_high": hi, "paired_t_pvalue": t_p, "wilcoxon_pvalue": w_p}


def main():
    df = pd.read_csv(TABLE_DIR / "all_algorithm_results_combined.csv")
    variants = sorted(df["model_variant"].dropna().unique())
    rows_vs_z = []
    for model in variants:
        if model == "ZScore":
            continue
        for metric in METRICS:
            r = paired(df, model, "ZScore", metric)
            if r:
                rows_vs_z.append(r)
    rows_pairwise = []
    for i, a in enumerate(variants):
        for b in variants[i+1:]:
            r = paired(df, a, b, "sharpe")
            if r:
                rows_pairwise.append(r)
    vs_z = pd.DataFrame(rows_vs_z)
    pairwise = pd.DataFrame(rows_pairwise)
    vs_z.to_csv(TABLE_DIR / "stat_tests_vs_zscore.csv", index=False)
    pairwise.to_csv(TABLE_DIR / "stat_tests_pairwise_sharpe.csv", index=False)
    with pd.ExcelWriter(TABLE_DIR / "statistical_tests_all_algorithms.xlsx", engine="openpyxl") as writer:
        vs_z.to_excel(writer, sheet_name="Vs ZScore", index=False)
        pairwise.to_excel(writer, sheet_name="Pairwise Sharpe", index=False)
    print("Saved statistical tests.")

if __name__ == "__main__":
    main()
