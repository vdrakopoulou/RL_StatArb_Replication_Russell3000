python .\scripts\00_check_environment.py
python .\scripts\01_build_tickers_from_bloomberg_export.py --members-file .\data\raw\russell3000_members.xlsx
python .\scripts\02_download_russell3000_ohlcv.py --sleep 0.35
python .\scripts\03_download_regime_data.py
python .\scripts\04_download_metadata.py
python .\scripts\05_clean_filter_build_panel.py
python .\scripts\06_select_dynamic_pairs.py
python .\scripts\07_build_rl_pair_dataset.py
python .\scripts\08_train_discrete_ppo_a2c.py --timesteps 100000
python .\scripts\09_train_a2c_directional_reward.py --timesteps 100000
python .\scripts\10_train_sac_continuous.py --timesteps 100000
python .\scripts\11_train_td3_continuous.py --timesteps 100000 --resume
python .\scripts\12_compare_all_algorithms.py
python .\scripts\13_statistical_tests.py
