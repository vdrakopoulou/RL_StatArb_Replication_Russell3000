# Full Code Replication Package

**Paper:** The Limits of AI-Based Statistical Arbitrage: Evidence from Discrete and Continuous Reinforcement Learning in a Large Equity Universe

This package contains the full public-safe code pipeline from Bloomberg data collection to reinforcement-learning training and statistical evaluation. It is intended for researchers with licensed Bloomberg access who want to reproduce the empirical workflow.

## Included code

- Build Russell 3000 Bloomberg ticker list from a Bloomberg Excel export
- Download Bloomberg OHLCV, market capitalization, market-regime, and metadata fields
- Construct a clean stock panel and liquidity-screened tradable universe
- Select dynamic same-sector pairs using correlation, cointegration, half-life, and liquidity ranking
- Build reinforcement-learning pair datasets
- Train PPO and A2C in a discrete long/short/flat environment
- Train reward-shaped A2C directional model
- Train SAC and TD3 in a continuous target-exposure environment
- Combine all algorithm results and run paired statistical tests

## Not included

Raw Bloomberg data, processed Parquet data, Bloomberg membership exports, trained models, trade logs, and daily return logs are not included because they may be subject to Bloomberg and institutional licensing restrictions.

## Quick start

```powershell
python -m venv .venv
.\.venv\Scripts\activate
python -m pip install -r requirements.txt
python .\scripts\00_check_environment.py
```

Place the Bloomberg Russell 3000 membership Excel export at:

```text
data/raw/russell3000_members.xlsx
```

Then run the full pipeline:

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\run_full_pipeline.ps1
```

Or follow the detailed run order in `docs/RUN_ORDER.md`.

## Main outputs

```text
outputs/results/
outputs/models/
outputs/tables/
```

## Data-licensing statement

This package provides code and documentation only. Users are responsible for ensuring that their Bloomberg usage complies with their institutional and Bloomberg data agreements.
