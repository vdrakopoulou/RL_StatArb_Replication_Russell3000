# Full run order

Run from the package root.

## 1. Bloomberg membership export to ticker file
```powershell
python .\scripts\01_build_tickers_from_bloomberg_export.py --members-file "C:\path\to\russell3000_members.xlsx"
```

## 2. Bloomberg data collection
```powershell
python .\scripts\02_download_russell3000_ohlcv.py --limit 10
python .\scripts\03_download_regime_data.py
python .\scripts\04_download_metadata.py --limit 10
```
Remove `--limit` after testing.

## 3. Data cleaning and pair selection
```powershell
python .\scripts\05_clean_filter_and_build_regime.py
python .\scripts\06_dynamic_pair_selection.py --test-year 2022
```
Remove `--test-year` for the full 2016-2025 walk-forward run.

## 4. RL dataset construction
```powershell
python .\scripts\07_build_rl_pair_dataset.py --test-year 2022 --max-pairs 20
```
Remove `--test-year` and `--max-pairs` for the full dataset.

## 5. Discrete RL training
```powershell
python .\scripts\08_train_ppo_a2c.py --test-year 2022 --max-pairs 20 --timesteps 20000
```
Full run:
```powershell
python .\scripts\08_train_ppo_a2c.py --timesteps 100000
```

## 6. Reward engineering
```powershell
python .\scripts\09_train_reward_engineered_ppo_a2c.py --test-year 2022 --max-pairs 20 --timesteps 20000
python .\scripts\10_train_directional_a2c.py --test-year 2022 --max-pairs 20 --timesteps 20000
```

## 7. Continuous RL training
```powershell
python .\scripts\11_train_sac_continuous.py --test-year 2022 --max-pairs 20 --timesteps 20000
python .\scripts\12_train_td3_continuous.py --test-year 2022 --max-pairs 20 --timesteps 20000
```
Full run:
```powershell
python .\scripts\11_train_sac_continuous.py --timesteps 100000 --max-pairs 100
python .\scripts\12_train_td3_continuous.py --timesteps 100000 --max-pairs 100
```

## 8. Comparison and statistical tests
```powershell
python .\scripts\13_compare_all_algorithms.py
python .\scripts\14_statistical_tests.py
```
