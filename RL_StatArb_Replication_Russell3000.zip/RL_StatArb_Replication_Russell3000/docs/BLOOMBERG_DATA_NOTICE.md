# Bloomberg Data Notice

This code uses Bloomberg-derived data, including Russell 3000 membership, OHLCV, market capitalization, sector metadata, SPX, VIX, and U.S. Treasury data. The code is provided for replication by researchers with appropriate Bloomberg access. Raw and processed Bloomberg-derived data are not included in this package and should not be redistributed unless permitted by the applicable Bloomberg and institutional licenses.
