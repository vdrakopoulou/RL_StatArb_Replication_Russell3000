# Expected Outputs

After running the full pipeline, the project root should contain:

```text
raw/
  russell3000_tickers.csv
  stocks/*.parquet
  regime/*.parquet
  metadata.csv
processed/
  clean_stock_panel.parquet
  tradable_universe.csv
  market_regime_features.parquet
  dynamic_pairs_walkforward.csv
  rl_pair_dataset/*.parquet
models/
  PPO_YYYY.zip
  A2C_YYYY.zip
  SAC_*.zip
  TD3_*.zip
results/
  rolling_walkforward_rl_results.csv
  a2c_directional_results.csv
  sac_continuous_results.csv
  td3_continuous_results.csv
tables/
  all_algorithm_results_combined.csv
  statistical_tests_all_algorithms.xlsx
```
